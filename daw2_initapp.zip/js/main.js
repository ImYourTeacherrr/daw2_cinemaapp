var mG
var d

/*
d = new clsDebug();
d.log("que tal");
d.openurl("https://www.w3schools.com");
*/


window.onload= function(){
    if (document.readyState=="complete"){
        mG = new clsMyGame(); 
        mG.totext();
    }
}