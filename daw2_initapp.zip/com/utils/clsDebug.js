class clsDebug{


    constructor (){
        console.log("Objeto de la clase clsDebug creada");
    }


    log (pValue){
        console.log(pValue);
    }

    openurl(pValue){
        window.open(pValue);
    }

}