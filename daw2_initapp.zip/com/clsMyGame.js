


class clsMyGame{


    constructor (){
        console.log("Objeto de la clase clsMyGame creada");
    }


    totext (){
        console.log("totext method");

    }


}